document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
        document.getElementById("camBtn").addEventListener("click", clickHandler)
};
function clickHandler(){
    navigator.camera.cleanup(onSuccess, onFail);
    navigator.camera.getPicture(ongetPictureSuccess, onFail, { quality: 50,
        destinationType: Camera.DestinationType.FILE_URI });
};
function onSuccess() {
    document.getElementById("log").innerHTML += "<p> Camera cleanup success.</p>";
};
function onFail(message) {
    document.getElementById("log").innerHTML += message.type+"<p> Camera cleanup failed.</p>";
};
function ongetPictureSuccess(imageURI) {
    var image = document.getElementById('photo');
    image.src = imageURI;
}
