document.addEventListener('deviceready', onDeviceReady, false);
function onDeviceReady() {
    document.querySelector("#log").innerHTML += "<li> cordova :"+device.cordova+"</li>";
    document.querySelector("#log").innerHTML += "<li> model :"+device.model+"</li>";
    document.querySelector("#log").innerHTML += "<li> platform :"+device.platform+"</li>";
    document.querySelector("#log").innerHTML += "<li> uuid :"+device.uuid+"</li>";
    document.querySelector("#log").innerHTML += "<li> version :"+device.version+"</li>";
    document.querySelector("#log").innerHTML += "<li> manufacturer :"+device.manufacturer+"</li>";
    document.querySelector("#log").innerHTML += "<li> isVirtual :"+device.isVirtual+"</li>";
    document.querySelector("#log").innerHTML += "<li> serial :"+device.serial+"</li>";
}
