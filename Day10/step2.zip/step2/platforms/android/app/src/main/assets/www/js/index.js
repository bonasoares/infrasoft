document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {

    var elm = document.querySelector("#log");
    window.addEventListener("batterystatus", onBatteryStatus, false);

    function onBatteryStatus(status) {
        elm.innerHTML += "<p> Battery Level status is : "+status.level+"</p>";
        elm.innerHTML += "<p> Battery isPlugged status is : "+status.isPlugged+"</p>";
    }
}
