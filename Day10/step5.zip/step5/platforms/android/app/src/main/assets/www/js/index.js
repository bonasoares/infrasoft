document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    setTimeout(function(){
        Cordova.exec(successFun, errorFun, "InfrasoftPlugin", "coolMethod",[1,2,3])
    }, 2000)
    
};

function successFun(sumofall){
    document.querySelector(".app").innerHTML = "Plugin Success Return : "+sumofall;
}
function errorFun(error){
    document.querySelector(".app").innerHTML = "Plugin Error : "+error;
}
