cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "com.infrasoft.vijay.InfrasoftPlugin",
      "file": "plugins/com.infrasoft.vijay/www/InfrasoftPlugin.js",
      "pluginId": "com.infrasoft.vijay",
      "clobbers": [
        "cordova.plugins.InfrasoftPlugin"
      ]
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-whitelist": "1.3.4",
    "com.infrasoft.vijay": "1.0.0"
  };
});